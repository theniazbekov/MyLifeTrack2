package com.example.mylifetrack.interfaces;

public interface OnItemClick {
    void itemClick(int position);
}
