package com.example.mylifetrack.interfaces;

import com.example.mylifetrack.models.TaskModel;

public interface OnItemListener {
    void onItemClick(TaskModel model);
}
